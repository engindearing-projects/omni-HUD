
package com.engindearing.omnicot.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class ExampleTest {
    @Test
    public void basicArithmetic() {
        assertEquals(4, 2 + 2);
    }
}
